We use ExternalDNS to map ingress rules to Azure DNS zone

[tutorial](https://github.com/kubernetes-incubator/external-dns/blob/master/docs/tutorials/azure.md)
