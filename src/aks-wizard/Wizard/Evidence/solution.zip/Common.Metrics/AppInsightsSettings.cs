namespace Common.Metrics
{
    public class AppInsightsSettings
    {
        public string InstrumentationKeySecret { get; set; }
        public string InstrumentationKey { get; set; }
    }
}